use voter_crm;

delete from voter_crm.subscriptions;

delete from voter_crm.candidates;

delete from voter_crm.voterdetails;

delete from voter_crm.voters;

delete from voter_crm.politicalparties;

delete from voter_crm.pollingstations;

delete from voter_crm.assemblyconstituency;

delete from voter_crm.districts;

delete from voter_crm.states;

delete from voter_crm.logins;

delete from voter_crm.admincandidatemapping;

delete from voter_crm.agents;