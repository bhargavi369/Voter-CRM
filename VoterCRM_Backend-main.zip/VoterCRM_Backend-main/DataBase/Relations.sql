USE voter_crm;

CREATE TABLE Relations(
      Relation_Id int PRIMARY KEY AUTO_INCREMENT,
      Relation_Name varchar(50) UNIQUE NOT NULL
);