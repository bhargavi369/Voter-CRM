Create datadase voterCrm;
